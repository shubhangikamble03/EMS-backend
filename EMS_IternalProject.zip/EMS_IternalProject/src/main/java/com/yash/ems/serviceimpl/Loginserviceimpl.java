package com.yash.ems.serviceimpl;
//package com.example.demo.serviceimpl;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.example.demo.model.Login;
//import com.example.demo.repo.LoginRepository;
//import com.example.demo.service.LoginService;
//
////@Service
//public class Loginserviceimpl implements LoginService {
//	
//	@Autowired
//	LoginRepository studentRepository;
//
//	@Override
//	public Login logindataByUsernameAndPassword(String username, String password) {
//		// TODO Auto-generated method stub
//		
//		return studentRepository.findByUsernameAndPassword(username, password);
//		
//	}
//
//}
