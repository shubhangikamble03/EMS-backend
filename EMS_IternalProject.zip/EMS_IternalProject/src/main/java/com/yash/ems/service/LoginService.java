package com.yash.ems.service;
//package com.example.demo.service;
//
//import com.example.demo.model.Login;
//
//public interface LoginService {
//
//	Login logindataByUsernameAndPassword(String username, String password);
//
//}
