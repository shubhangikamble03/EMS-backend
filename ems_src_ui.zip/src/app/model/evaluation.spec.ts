import { Evaluation } from './evaluation';

describe('Evaluation', () => {
  it('should create an instance', () => {
    expect(new Evaluation()).toBeTruthy();
  });
});
