export class Rating {
   ratingId:number;
   ratingDesc:string;
   ratingBriefDesc:string

}
