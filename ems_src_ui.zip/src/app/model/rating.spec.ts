import { Rating } from './rating';

describe('Rating', () => {
  it('should create an instance', () => {
    expect(new Rating()).toBeTruthy();
  });
});
