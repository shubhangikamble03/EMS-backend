

export class Evaluation {
    evaluationId:number;
    overallRating:string;
    overallComment:string;
    evaluationDate:Date;
    angular:string;
  coreJava:string;
	react:string;
	  springBoot:string;
	  mySQL:string;
	 aws:string;
   evaluatedBy:string;
   clientName:string;
}
