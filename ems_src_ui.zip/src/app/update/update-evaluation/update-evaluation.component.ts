import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { EmployeedetailsComponent } from 'src/app/details/employeedetails/employeedetails.component';
import { Employee } from 'src/app/model/employee';
import { Evaluation } from 'src/app/model/evaluation';
import { Rating } from 'src/app/model/rating';
import { Skills } from 'src/app/model/skills';
import { EmployeeserviceService } from 'src/app/services/employeeservice.service';
import { EvaluationService } from 'src/app/services/evaluation.service';
import { RatingService } from 'src/app/services/rating.service';

@Component({
  selector: 'app-update-evaluation',
  templateUrl: './update-evaluation.component.html',
  styleUrls: ['./update-evaluation.component.css']
})
export class UpdateEvaluationComponent implements OnInit{

  employee:Employee;
  evid: number;
  evaluation: Evaluation;
  empid;
  evalForm: any;
  rating: Rating;
  r: Rating[];

  ed:EmployeedetailsComponent;

  overallRating=["Need to Improvement","Average","Intermediate","Good","Excellent"];
  overall;
  
  
  

  currentDate;
  ename: string;

  constructor(private _router:Router,private evservice:EvaluationService, 
    private empservice:EmployeeserviceService,
    private ratingService:RatingService, private datePipe:DatePipe,
    private route: ActivatedRoute,private formbuilder:FormBuilder) {
      // this.currentDate=this.datePipe.transform((new Date),'yyyy-MM-dd');
      // console.log(this.currentDate);
     }
     ra:Array<any>;

  ngOnInit(): void {
    this.getRating();
  
    this.ratingService.getAllRating().subscribe(
      (data:any)=>{
        this.r=data;
        
        console.log(data)
      }
     )

    this.evaluation=new Evaluation();
    this.evid= this.route.snapshot.params['evaluationId'];
this.empid=this.route.snapshot.params['employeeId'];


this.evservice.fetchEvaluation(this.empid,this.evid).subscribe(
  data=>{
    console.log(this.evid);
    this.evaluation = data;
    console.log(this.evaluation);
    
  }, error => console.log(error)

);


if(this.empId= this.route.snapshot.params['employeeId']){
  this.empservice.fetchEmployeeById(this.empId).subscribe(data=>
    {
    
      this.employee = data;
      this.ename=this.employee.employeeName;
      console.log(this.employee);
    }, error => console.log(error))
 
  }    

console.log(this.ename)
this.evservice.fetchEvalutionById(this.evid).subscribe(
  data=>{
    console.log(this.evid);
    this.evaluation = data;
    console.log(this.evaluation);
    
  }, error => console.log(error));
  
  }

  submitEvaluation(){
    this.update();
  }
  empId:number;
  update() {
   
    this.evid= this.route.snapshot.params['evaluationId'];
    this.empid=this.route.snapshot.params['employeeId'];
    console.log(this.evid)
      this.evservice.updateEvalutionById(this.evid,this.evaluation).subscribe(data =>{
        console.log(data);
        this.evaluation=new Evaluation();
        this._router.navigate(['/dashboard/view-evaluation/',this.empid,this.evid]);
        
       // this.ed.showEvaluation(this.empId);
        this.goToEvaluationList();
        }
        , error => console.log(error));


        //update By only evaluation Id
        
  }
  goToEvaluationList() {
    
    this.empid= this.route.snapshot.params['employeeId'];
    this.evid=this.route.snapshot.params['evaluationId']
    this._router.navigate(['/dashboard/view-evaluation/',this.empid])
   }
dess:string;
  getRating(){
    this.ratingService.getAllRating().subscribe(
      data=>{
        console.log(data);
        this.r=data;
    
        console.log("response recived ");
      },error=>{
        console.log("exception occured");
      }
  
     )
  }


  getBack(){
    this.empid=this.route.snapshot.params['employeeId'];
    this.evid= this.route.snapshot.params['evaluationId'];
    this._router.navigate(['/dashboard/view-evaluation',this.empid])
  
     // this.startEvaluation(id);;
  
    }

  desc;
  change(descb){
    this.desc=descb.target.value;
    console.log(descb.target.value)
  }

  change1(descb){
    this.overall=descb.target.value;
    console.log(descb.target.value)
  }
}
