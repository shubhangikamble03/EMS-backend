import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Evaluation } from '../model/evaluation';

@Injectable({
  providedIn: 'root'
})
export class EvaluationService {
  

  constructor(private http:HttpClient) { }


  deleteEvaluationByRemote(evaluationId: number) {
    return this.http.delete('');
   }

  fetchEvalutionById(evalituinId: number):Observable<any> {
    return this.http.get("http://localhost:7079/ems/evaluation/get-by-evaluation-id/"+evalituinId);
  }
   
   updateEvalutionById(evaluationId:number,evaluation:Evaluation):Observable<Evaluation>
   {
    
     return this.http.put<Evaluation>("http://localhost:7079/ems/evaluation/"+evaluationId+"/evaluation",evaluation);
   }
  
   fetchEvaluation(employeeId:number,evaluationId:number):Observable<any>{
    return this.http.get("http://localhost:7079/ems/employee/evaluation/"+employeeId+"/"+evaluationId);
   }
}
