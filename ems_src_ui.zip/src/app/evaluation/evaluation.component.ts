import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../model/employee';
import { EmployeeserviceService } from '../services/employeeservice.service';

@Component({
  selector: 'app-evaluation',
  templateUrl: './evaluation.component.html',
  styleUrls: ['./evaluation.component.css']
})
export class EvaluationComponent implements OnInit {
  employee=new Employee();
  employeeList: any;

  constructor(private employeeService:EmployeeserviceService,private _router:Router) { }

  msg="";
empId;
searchText;
  changeEmployeeId(id){
this.empId=id.target.value;
console.log(id.target.value)
  }


  changeId(descb){
    this.empId=descb.target.value;
    console.log(descb.target.value)
  }

  
  ngOnInit(): void {
   this.employeeService.fetchEmployeeDetailsByRemote().subscribe(
    (data:any)=>{
      this.employeeList=data;
    }
   )
  }
input:any;
s:any;
id:any;
e:any;
startEvaluation(empId:any){
  //input=this.employee.employeeId;

 if(empId=this.employee.employeeId){
  console.log(empId)
  
  this.s=empId;
  this.id=this.s.split("-");
  console.log(this.id[0]);
 
  this.e=this.id[0];
  var number=parseInt(this.e);
  
 
  this.employeeService.fetchEmployeeById(number).subscribe(
    data=>{
      console.log(data);
      this.employee=data;
      this._router.navigate(["/dashboard/add-evaluation-byId/",number])
    }
  )}


  if(empId=this.employee.employeeName){
    this.employeeService.fetchEmployeeByName(empId).subscribe ( data=>{
      console.log(data);
      this.employee=data;
      this._router.navigate(["/dashboard/add-evaluation-byName/",empId])
    }
  )
  }
  
}

  startEval(empId,employeeName:string)
  {
    empId=this.employee.employeeId;
    employeeName=this.employee.employeeName;
    this.employeeService.fetchByIdAndName
    (empId,employeeName).subscribe(k=>{
      console.log(k);
      console.log(this.employee.employeeName);
      this.employee=k;
   //  this._router.navigateByUrl("/dashboard/add-evaluation",employeeId,employeeName);
    // this._router.navigate(["/dashboard/add-evaluation/",empId,employeeName])
      
      // if(k!="")
      // {
      //   Swal.fire("Login sucessfully","welcome","success");
      //   this._router.navigateByUrl("/dashboard/evaluationform");
      // }
      // else{
      //   Swal.fire("Sorry");
      // }
    })
  
  
  }

  getBack(){
  this._router.navigate(['/dashboard/employeedetails'])

   // this.startEvaluation(id);;

  }
}
