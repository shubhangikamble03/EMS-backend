import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-evaluationsdetails',
  templateUrl: './evaluationsdetails.component.html',
  styleUrls: ['./evaluationsdetails.component.css']
})
export class EvaluationsdetailsComponent  implements OnInit {
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  
}