import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/app/model/employee';
import { EmployeeserviceService } from 'src/app/services/employeeservice.service';
import Swal from 'sweetalert2';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-employeedetails',
  templateUrl: './employeedetails.component.html',
  styleUrls: ['./employeedetails.component.css']
})
export class EmployeedetailsComponent  implements OnInit{
  employee: Employee[];
  searchText;
  t=new Employee();
  isEditItems: boolean;


  POSTS: any;
  page: number = 1;
  count: number = 0;
  tableSize: number = 5;
  tableSizes: any = [5, 10, 15, 20];
  constructor(private router:Router,private empService:EmployeeserviceService){

  }
  
  ngOnInit(): void {
   this.fetchEmployees();

 // this.updateEmployee();


 
}


fetchEmployees(){
  this.empService.fetchEmployeeDetailsByRemote().subscribe(
    data=>{
      console.log(data);
      this.POSTS = data;
      this.employee=this.POSTS;
      console.log(this.t)
      console.log("response recived");
    },error=>{
      console.log("exception occured");
    }

)
}

onTableDataChange(event: any) {
  this.page = event;
  this.fetchEmployees();
}
onTableSizeChange(event: any): void {
  this.tableSize = event.target.value;
  this.page = 1;
  this.fetchEmployees();
}

  add(){
    console.log("ONBOARD")
    this.router.navigateByUrl("/dashboard/onboard");
  }

  onEditCloseItems(){}

  

  updateEmployee(employeeId:number){
    console.log("update by ID",employeeId);
    this.router.navigate(['/dashboard/updateEmployeeById',employeeId]);
  }



  deleteEmployee(employeeId:number){
    // if( Swal.fire('warning',
    // 'Are you Sure','question'))
  if(confirm("are you sure deleted "))
   {
    this.empService.deleteEmplyeeByRemote(employeeId).subscribe(
     res=>{
       alert("Record deleted successfully!");
       //Swal.fire("warning","Are you Sure you want to delete",'question');
       //Swal.getCancelButton()
       this.ngOnInit();
     })
    }
    else{
     this.fetchEmployees();
    }
  }

  view(employeeId:number){
    this.router.navigate(['/dashboard/view-employee/',employeeId]);
  }

  showEvaluation(employeeId){
    this.router.navigate(['/dashboard/view-evaluation/',employeeId]);
  }

ExcelData:any;
  readExcel(event:any){
    let file=event.target.files[0];
    let fileReader=new FileReader();
    fileReader.readAsBinaryString(file);

    fileReader.onload = (e)=>{
      var workBook=XLSX.read(fileReader.result,{type:'binary'});
      var sheetNames=workBook.SheetNames;
     this.ExcelData= XLSX.utils.sheet_to_json(workBook.Sheets[sheetNames[0]])
     console.log(this.ExcelData);
    }
  }

}
