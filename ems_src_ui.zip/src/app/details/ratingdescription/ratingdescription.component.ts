import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ratingdescription',
  templateUrl: './ratingdescription.component.html',
  styleUrls: ['./ratingdescription.component.css']
})
export class RatingdescriptionComponent  implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  getBack(){

this.router.navigate[('/dashboard/add-evaluation-byId')]
  }
}
