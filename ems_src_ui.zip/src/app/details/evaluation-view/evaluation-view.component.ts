import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Evaluation } from 'src/app/model/evaluation';
import { EmployeeserviceService } from 'src/app/services/employeeservice.service';

@Component({
  selector: 'app-evaluation-view',
  templateUrl: './evaluation-view.component.html',
  styleUrls: ['./evaluation-view.component.css']
})
export class EvaluationViewComponent implements OnInit{
  evaluationlist:Evaluation[];
  evaluation=new Evaluation();
id;
serarchText;
  name;

  id1=this.route.snapshot.params['employeeId'];
  
  constructor(private service:EmployeeserviceService,
    private route:ActivatedRoute,
    private router:Router
    ){}
  ngOnInit(): void {
    console.log("id1"+this.id1);
    

    if(this.id= this.route.snapshot.params['employeeId']){
             this.service.showEvaluationById(this.id).subscribe(
                data=>{
                   this.evaluationlist=data;
              }
    );
    }

    if(this.name= this.route.snapshot.params['employeeName']){
    this.service.showEvaluationByName(this.name).subscribe(
      data=>{
                 this.evaluationlist=data;
      }
    );
    }
  }

  updateEvaluation(evaluationId:number){
    this.router.navigate(['/dashboard/updateEvaluationById',evaluationId]);

  }

  updateEval(id1:number,evaluationId:number){
   id1=this.id1;
    this.router.navigate(['/dashboard/update-evaluation',this.id1,evaluationId])
  }
  

}
